-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 22, 2018 at 11:05 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `esbalkan`
--

-- --------------------------------------------------------

--
-- Table structure for table `clans`
--

CREATE TABLE `clans` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `cover` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `leader` varchar(255) NOT NULL,
  `gameleader` varchar(255) NOT NULL,
  `wins` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `activity` varchar(10) NOT NULL,
  `created_at` varchar(50) NOT NULL,
  `modified_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clans`
--

INSERT INTO `clans` (`id`, `name`, `avatar`, `cover`, `description`, `leader`, `gameleader`, `wins`, `country`, `activity`, `created_at`, `modified_at`) VALUES
(1, 'Mysterious', '', '', 'POzdrav i dobrodosli na officijalnu Mysterious clan stranicu. Ovdje mozete pronaci nase najnovije rezultate, te pratiit napredak naseg klana. Stay tuned!', '6', '4', '160', 'bosnia', 'Active', '11-06-2018', '2018-06-10 23:48:32');

-- --------------------------------------------------------

--
-- Table structure for table `configs`
--

CREATE TABLE `configs` (
  `id` int(11) NOT NULL,
  `user_id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `downloads` int(255) NOT NULL,
  `uniquedownloads` int(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `configs`
--

INSERT INTO `configs` (`id`, `user_id`, `name`, `downloads`, `uniquedownloads`, `created_at`, `modified_at`) VALUES
(1, 4, 'OstVMyHP75vuEIKQdhgR2rDCjqUFpeXW', 13, 2, '2018-07-23 13:18:36', '2018-07-23 13:18:36');

-- --------------------------------------------------------

--
-- Table structure for table `downloads`
--

CREATE TABLE `downloads` (
  `id` int(11) NOT NULL,
  `config_id` int(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `downloads`
--

INSERT INTO `downloads` (`id`, `config_id`, `ip`, `created_at`) VALUES
(3, 1, '127.0.0.1', '2018-06-10 04:55:17'),
(4, 1, '127.0.0.1', '2018-06-10 04:55:18'),
(5, 1, '127.0.0.1', '2018-06-10 04:55:40'),
(6, 1, '127.0.0.1', '2018-06-10 04:55:47'),
(7, 1, '127.0.0.1', '2018-06-10 04:55:51'),
(8, 1, '127.0.0.1', '2018-06-10 04:55:52'),
(9, 1, '::1', '2018-06-10 05:00:54'),
(10, 1, '::1', '2018-06-10 05:01:20'),
(11, 1, '::1', '2018-06-10 05:59:14'),
(12, 1, '::1', '2018-06-10 06:32:17'),
(13, 1, '::1', '2018-06-10 07:02:07'),
(14, 1, '::1', '2018-06-10 11:25:49'),
(15, 1, '::1', '2018-06-15 14:25:10'),
(16, 1, '::1', '2018-06-15 14:25:43'),
(17, 1, '::1', '2018-07-23 13:18:35');

-- --------------------------------------------------------

--
-- Table structure for table `hardware`
--

CREATE TABLE `hardware` (
  `id` int(11) NOT NULL,
  `user_id` int(255) NOT NULL,
  `cpu` varchar(255) NOT NULL,
  `gpu` varchar(255) NOT NULL,
  `ram` varchar(255) NOT NULL,
  `monitor` varchar(255) NOT NULL,
  `headset` varchar(255) NOT NULL,
  `keyboard` varchar(255) NOT NULL,
  `mouse` varchar(255) NOT NULL,
  `casing` varchar(255) NOT NULL,
  `disc` varchar(255) NOT NULL,
  `pad` varchar(255) NOT NULL,
  `motherboard` varchar(255) NOT NULL,
  `created_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hardware`
--

INSERT INTO `hardware` (`id`, `user_id`, `cpu`, `gpu`, `ram`, `monitor`, `headset`, `keyboard`, `mouse`, `casing`, `disc`, `pad`, `motherboard`, `created_at`) VALUES
(1, 4, 'Intel i7 7400 lootlake', 'nVIDIA GT 1030', 'HyperX 8GB DDR4', 'Asus G', 'SteelSeries Siberia 2', 'MS Pro1', 'Razer Pro', 'MS Build', 'Kingstone', 'Steelseries', 'Asus NMP', '2018-06-05');

-- --------------------------------------------------------

--
-- Table structure for table `profilecomments`
--

CREATE TABLE `profilecomments` (
  `id` int(11) NOT NULL,
  `profile_id` varchar(255) NOT NULL,
  `commenter_id` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profilecomments`
--

INSERT INTO `profilecomments` (`id`, `profile_id`, `commenter_id`, `comment`, `created_at`) VALUES
(41, '5', '4', 'Prvi com\r\n', '2018-06-06 20:46:57'),
(42, '5', '4', 'Drugi com\r\n', '2018-06-06 20:47:14'),
(43, '5', '4', 'treci com', '2018-06-06 20:47:21'),
(44, '5', '4', 'cetvrti', '2018-06-06 20:47:26'),
(45, '5', '4', 'peti', '2018-06-06 20:47:31'),
(46, '5', '4', 'sesti', '2018-06-06 20:47:37'),
(47, '5', '4', 'sedmi', '2018-06-06 20:47:42'),
(48, '5', '4', 'osmi', '2018-06-06 20:47:47'),
(49, '5', '4', 'deveti', '2018-06-06 20:47:52'),
(50, '5', '4', 'aaaa', '2018-06-06 20:52:17'),
(51, '4', '4', 'aaaaa', '2018-06-06 20:54:29'),
(52, '4', '4', 'aaaaaa', '2018-06-06 20:54:31'),
(53, '4', '4', 'aaa', '2018-06-06 20:54:34'),
(54, '4', '4', 'aaaaaaaaaaaaaaaaaaaa', '2018-06-06 20:54:37'),
(55, '4', '4', 'aaaaaa', '2018-06-06 20:54:42'),
(56, '4', '4', 'jebo ti sve svoje', '2018-06-06 21:21:39'),
(57, '4', '4', '<b>aaa</b>', '2018-06-06 21:21:53'),
(58, '4', '4', '<h2>aaa</h2>\r\n[removed]alert&#40;''aaaa''&#41;[removed]', '2018-06-06 21:22:49'),
(59, '4', '4', '&lt;b&gt;aaa&lt;/b&gt;', '2018-06-06 21:35:17'),
(60, '4', '4', 'aaa', '2018-06-06 22:12:20'),
(61, '4', '4', 'aaa\r\n', '2018-06-07 02:01:46'),
(62, '4', '4', 'novi kom', '2018-06-07 07:11:49'),
(63, '4', '4', 'aaaa', '2018-06-07 07:27:04'),
(64, '7', '7', 'Dobro dosli na moj profil.', '2018-06-07 07:54:28'),
(65, '5', '5', 'moj koment\r\n', '2018-06-08 22:56:25'),
(66, '4', '4', 'aa', '2018-06-10 02:29:14'),
(67, '6', '6', 'test\r\n', '2018-06-10 07:41:07'),
(68, '4', '6', 'moj kom', '2018-06-10 07:43:46'),
(69, '4', '6', 'moj drugi komentar\r\n', '2018-06-10 07:45:58'),
(70, '5', '6', 'moj kom', '2018-06-10 07:47:33'),
(71, '4', '5', 'eeee sta ima?', '2018-06-10 10:40:36'),
(72, '4', '4', 'nista', '2018-06-15 07:32:48'),
(73, '6', '4', 'test 2\r\n', '2018-06-15 07:36:18');

-- --------------------------------------------------------

--
-- Table structure for table `turnir8`
--

CREATE TABLE `turnir8` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `owner_id` int(50) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `rules` varchar(120) NOT NULL,
  `team1` varchar(100) NOT NULL,
  `team2` varchar(100) NOT NULL,
  `team3` varchar(100) NOT NULL,
  `team4` varchar(100) NOT NULL,
  `team5` varchar(100) NOT NULL,
  `team6` varchar(100) NOT NULL,
  `team7` varchar(100) NOT NULL,
  `team8` varchar(100) NOT NULL,
  `first` varchar(100) NOT NULL,
  `second` varchar(100) NOT NULL,
  `third` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `edited_at` varchar(111) NOT NULL,
  `turnirstarting` varchar(111) NOT NULL,
  `started` varchar(111) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `nickname` varchar(255) NOT NULL,
  `bdate` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(50) NOT NULL,
  `confirmed` tinyint(1) NOT NULL,
  `token` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `team` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `premium` varchar(5) NOT NULL,
  `newcomments` varchar(10) NOT NULL,
  `allcomments` varchar(10) NOT NULL,
  `config` varchar(15) NOT NULL,
  `config_id` int(15) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_banned` tinyint(1) NOT NULL,
  `modified_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `nickname`, `bdate`, `email`, `password`, `confirmed`, `token`, `role`, `avatar`, `country`, `team`, `description`, `premium`, `newcomments`, `allcomments`, `config`, `config_id`, `is_active`, `is_banned`, `modified_at`, `created_at`) VALUES
(4, 'Izet', 'Mulalic', 'kalle', '', 'kallegowild@gmail.com', '25f9e794323b453885f5181f1b624d0b', 0, 'e6cdfc42380ce0d5144c334f2007876de92f348e5504', '5', 'u38tiTvzdncSoKNYprPXUOxDqWkEa9Gj.jpg', 'bosnia', '1', 'Pozdrav moje ime je Izet Mulalic. Imam 18 godina, dolazim iz Buzima i trenutno igram u klanu Mysterious.\r\n\r\nU slobodno vrijeme bavim se programiranjem.', '', 'on', 'on', 'on', 0, 0, 0, '2018-07-23 13:17:24', '03-06-2018'),
(5, 'aaaaa', 'aaaaaaaaaa', 'aaaaaaa', '', 'hasan_mulalic@hotmail.com', '25f9e794323b453885f5181f1b624d0b', 0, '85a22e1e8fa7bdc2388642af7e477a753dedca0b9d06', '', '', 'serbia', '', 'Zovem se aaa i dolazim iz Srbije. Igram 1.6 aktivno 10 godina.', '', 'on', 'on', 'off', 0, 0, 0, '2018-07-23 15:36:49', '03-06-2018'),
(6, 'Mesud', 'Sijamhodzic', 'LEG1JADZEKO11', '', 'okkkssk@gmail.com', '25f9e794323b453885f5181f1b624d0b', 0, '6fa8384bc5abf8d9e89f292add5469f95c3aeb186190', '', 'ikl4sXfYgEu2h9wTbc7GrvUnHFPQL08M.jpg', 'bosnia', '1', '', '', 'on', 'on', 'on', 0, 0, 0, '2018-06-15 08:13:34', '10-06-2018');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clans`
--
ALTER TABLE `clans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `configs`
--
ALTER TABLE `configs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `downloads`
--
ALTER TABLE `downloads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hardware`
--
ALTER TABLE `hardware`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profilecomments`
--
ALTER TABLE `profilecomments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `turnir8`
--
ALTER TABLE `turnir8`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clans`
--
ALTER TABLE `clans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `configs`
--
ALTER TABLE `configs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `downloads`
--
ALTER TABLE `downloads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `hardware`
--
ALTER TABLE `hardware`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `profilecomments`
--
ALTER TABLE `profilecomments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;
--
-- AUTO_INCREMENT for table `turnir8`
--
ALTER TABLE `turnir8`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
